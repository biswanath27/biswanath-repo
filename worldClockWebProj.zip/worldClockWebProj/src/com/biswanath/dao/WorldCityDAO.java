package com.biswanath.dao;

import java.util.ArrayList;
import java.util.List;

import com.biswanath.bean.Country;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class WorldCityDAO {

	public static final String DBURL = "jdbc:oracle:thin:@localhost:1535:bishD";
	public static final String DBUSER = "test";
	public static final String DBPASS = "test@123";
	public static final String QUERY = "select country,city,latitude,longitude from location_test";
	public static final String COUNTRY = "country";
	public static final String CITY = "city";
	public static final String LATITUDE = "latitude";
	public static final String LONGITUDE = "longitude";

	public List<Country> getALLData() {

		List<Country> countryList = new ArrayList<Country>();
		Country country = null;
		ResultSet rs = null;
		try {
			DriverManager.registerDriver(new
			oracle.jdbc.driver.OracleDriver());
			Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASS);
			System.out.println("Connection:: " + con);
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery(QUERY);
			while (rs.next()) {
				country = new Country();
				country.setName(rs.getString(COUNTRY));
				country.setCity(rs.getString(CITY));
				country.setLatitude(rs.getString(LATITUDE));
				country.setLongitude(rs.getString(LONGITUDE));
				countryList.add(country);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("Going For Dummy Data.....");
			countryList=getDummyCountryList();
		}

		/*
		 * 
		 * String cityData="<?xml version='1.0'?>"+ "<countries>"+
		 * "<country><name>United States</name><city>New York</city><latitude>40.7142691</latitude><longitude>-74.0059738</longitude></country>"
		 * +
		 * "<country><name>United States</name><city>Los Angels</city><latitude>34.0522342</latitude><longitude>-118.2436829</longitude></country>"
		 * +
		 * "<country><name>United States</name><city>San Diegos</city><latitude>32.7153292</latitude><longitude>-117.1572571</longitude></country>"
		 * +
		 * "<country><name>United States</name><city>San Jose</city><latitude>37.3393857</latitude><longitude>-121.8949585</longitude></country>"
		 * +
		 * "<country><name>Japan</name><city>Tokyo</city><latitude>35.6895266</latitude><longitude>139.6916809</longitude></country>"+
		 * "<country><name>Australia</name><city>Sydney</city><latitude>-33.8678500</latitude><longitude>151.2073212</longitude></country>"+
		 * "<country><name>Switzerland</name><city>Zurich</city><latitude>47.3666667</latitude><longitude>8.5500002</longitude></country>"+
		 * "<country><name>Iceland</name><city>Reykjavik</city><latitude>64.1500000</latitude><longitude>-21.9500008</longitude></country>"+
		 * "<country><name>Mexico</name><city>Mexico City</city><latitude>19.4341667</latitude><longitude>-99.1386108</longitude></country>"
		 * +
		 * "<country><name>Peru</name><city>Lima</city><latitude>-12.0500000</latitude><longitude>-77.0500031</longitude></country>"+
		 * "</countries>"; List<Country> countryList = new ArrayList<Country>();
		 * Country country1 = new
		 * Country("United States","Los Angeles","34.0522342","-118.2436829");
		 * Country country2 = new
		 * Country("United States","New York","40.7142691","-74.0059738");
		 * Country country3 = new
		 * Country("United States","San Jose","37.3393857","-121.8949585");
		 * Country country4 = new
		 * Country("United States","San Diegos","32.7153292","-117.1572571");
		 * Country country5 = new
		 * Country("Japan","Tokyo","35.6895266","139.6916809"); Country country6
		 * = new Country("Australia","Sydney","-33.8678500","151.2073212");
		 * Country country7 = new
		 * Country("Switzerland","Zurich","47.3666667","8.5500002"); Country
		 * country8 = new
		 * Country("Iceland","Reykjavik","64.1500000","-21.9500008"); Country
		 * country9 = new
		 * Country("Mexico","Mexico City","19.4341667","-99.1386108"); Country
		 * country10 = new Country("Peru","Lima","-12.0500000","-77.0500031");
		 * 
		 * countryList.add(country1); countryList.add(country2);
		 * countryList.add(country3); countryList.add(country4);
		 * countryList.add(country5); countryList.add(country6);
		 * countryList.add(country7); countryList.add(country8);
		 * countryList.add(country9); countryList.add(country10);
		 */
		return countryList;

	}

	public boolean checkCordinates(String latitude, String longitude) {
		boolean response = false;
		System.out.println("Lati::: " + latitude);
		List<Country> allDataList = getALLData();
		if (allDataList != null && allDataList.contains(latitude)) {
			response = true;
		}
		return response;
	}

	private List<Country> getDummyCountryList() {
		List<Country> countryList = new ArrayList<Country>();
		Country country1 = new Country("United States", "Los Angeles", "34.0522342", "-118.2436829");
		Country country2 = new Country("United States", "New York", "40.7142691", "-74.0059738");
		Country country3 = new Country("United States", "San Jose", "37.3393857", "-121.8949585");
		Country country4 = new Country("United States", "San Diegos", "32.7153292", "-117.1572571");
		Country country5 = new Country("Japan", "Tokyo", "35.6895266", "139.6916809");
		Country country6 = new Country("Australia", "Sydney", "-33.8678500", "151.2073212");
		Country country7 = new Country("Switzerland", "Zurich", "47.3666667", "8.5500002");
		Country country8 = new Country("Iceland", "Reykjavik", "64.1500000", "-21.9500008");
		Country country9 = new Country("Mexico", "Mexico City", "19.4341667", "-99.1386108");
		Country country10 = new Country("Peru", "Lima", "-12.0500000", "-77.0500031");

		countryList.add(country1);
		countryList.add(country2);
		countryList.add(country3);
		countryList.add(country4);
		countryList.add(country5);
		countryList.add(country6);
		countryList.add(country7);
		countryList.add(country8);
		countryList.add(country9);
		countryList.add(country10);
		return countryList;
	}

	public static void main(String[] args) {
		WorldCityDAO dao = new WorldCityDAO();
		List<Country> contList = dao.getALLData();
		if (contList != null) {
			System.out.println("Country List Size:: " + contList.size());
		}
	}

}
