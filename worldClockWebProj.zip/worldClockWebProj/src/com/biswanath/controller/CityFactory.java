package com.biswanath.controller;

import com.biswanath.service.WorldCity;
import com.biswanath.service.WorldCityImpl;

public class CityFactory {
	
	public static WorldCity getWordCity(){
		WorldCity worldCity = new WorldCityImpl();
		return worldCity;
	}

}
