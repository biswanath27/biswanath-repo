package com.biswanath.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/testBiswa")
public class TestRest {
	@GET
	@Produces(MediaType.TEXT_XML)
	public String getNameALL(){
		
		String response="<?xml version='1.0'?><name>Biswanath Ghosh</name>";
		
		return response;
	}
	
	@GET
	@Produces(MediaType.TEXT_XML)
	@Path("/name")
	public String getName(){
		
		String response="<?xml version='1.0'?><name>Biswanath</name>";
		
		return response;
	}
	@GET
	@Produces(MediaType.TEXT_XML)
	@Path("{cityName}")
	public String getName(@PathParam("cityName")String cityName){
		
		String response="<?xml version='1.0'?><name>Biswanath from "+cityName+"</name>";
		
		return response;
	}
	
	@GET
	@Produces(MediaType.TEXT_XML)
	@Path("{latitude}/{longitude}")
	public String getData(@PathParam("latitude")String latitude,@PathParam("longitude")String longitude){
		
		String response="<?xml version='1.0'?><name>Biswanath from "+latitude +" ::  "+longitude+"</name>";
		
		return response;
	}
	
	

}
