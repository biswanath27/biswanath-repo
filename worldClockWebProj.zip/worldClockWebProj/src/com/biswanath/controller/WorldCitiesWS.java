package com.biswanath.controller;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.biswanath.bean.Country;
import com.biswanath.service.WorldCity;

@Path("/cities")
public class WorldCitiesWS {

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/allDataSets")
	public List<Country> getALLDataSets() {
		WorldCity worldCities = CityFactory.getWordCity();
		return worldCities.getAllCityData();
	}

	@GET
	@Produces(MediaType.TEXT_XML)
	@Path("{latitude}/{longitude}")
	public String getData(@PathParam("latitude") String latitude, @PathParam("longitude") String longitude) {
		String checkOrdi = "Record Found for Latitude" + latitude + " and Longitude " + longitude;
		WorldCity worldCities = CityFactory.getWordCity();
		boolean response = worldCities.checkCordinates(latitude, longitude);
		if (!response) {
			checkOrdi = "Not Found for Latitude " + latitude + " and Longitude " + longitude;
		}
		return checkOrdi;
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/country")
	public Country getCountry() {
		WorldCity worldCities = CityFactory.getWordCity();
		return worldCities.getCountry();
	}

	@POST
	@Path("/addCountry")
	@Consumes(MediaType.APPLICATION_XML)
	public Response consumeXML(Country country) {
		String output = country.toString();
		return Response.status(200).entity(output).build();

	}

}
