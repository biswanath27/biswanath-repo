package com.biswanath.service;

import java.util.List;

import com.biswanath.bean.Country;
import com.biswanath.dao.WorldCityDAO;

public class WorldCityImpl implements WorldCity {

	@Override
	public List<Country> getAllCityData() {
		WorldCityDAO wrdCityDao = new WorldCityDAO();
		return wrdCityDao.getALLData();
	}
	
	@Override
	public Country getCountry(){
		Country country = new Country("United States","Los Angeles","1234","1234");
		return country;
	}
	@Override
	public boolean checkCordinates(String latitude, String longitude){
		return false;
	}

}
