package com.biswanath.service;

import java.util.List;

import com.biswanath.bean.Country;

public interface WorldCity {
	public List<Country> getAllCityData();
	public Country getCountry();
	public boolean checkCordinates(String latitude, String longitude);
}
