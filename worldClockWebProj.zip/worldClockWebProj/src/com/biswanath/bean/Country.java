package com.biswanath.bean;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="countries")
public class Country {
	private String name;
	private String city;
	private String latitude;
	private String longitude;
	
	public Country(){
	
	}
	public Country(String name,String city,String latitude,String longitude){
		super();
		this.name=name;
		this.city=city;
		this.latitude=latitude;
		this.longitude=longitude;
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

}
